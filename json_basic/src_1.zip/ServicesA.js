import React from 'react'

function ServicesA() {
  return (
    <div><h2>ServicesA</h2></div>
  )
}

export default ServicesA