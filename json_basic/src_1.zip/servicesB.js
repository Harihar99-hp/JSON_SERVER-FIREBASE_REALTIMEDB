import React from 'react'

function servicesB() {
  return (
    <div><h2>servicesB</h2></div>
  )
}

export default servicesB