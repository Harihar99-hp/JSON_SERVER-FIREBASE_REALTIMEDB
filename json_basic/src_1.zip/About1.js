import React from 'react'

function About1() {
  return (
    <div>
      <h2>Aboutpage1</h2>
    </div>
  )
}

export default About1